#include <jni.h>
#include <android/log.h>
#include <string>
#include "./Utils/elf_util.h"

#define LOG_TAG "HiddenAPI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Fix macro redefinition by undefining old one if needed
#ifdef LOG_TAG
#undef LOG_TAG
#endif
#define LOG_TAG "HiddenAPI"

void disable_hidden_api(JNIEnv* env) {
    ElfImg elf_img("/system/framework/libart.so");

    void *addr = elf_img.getSymbAddress(
        "_ZN3artL32VMRuntime_setHiddenApiExemptionsEP7_JNIEnvP7_jclassP13_jobjectArray"
    );

    if (!addr) {
        LOGE("Failed to find symbol for hidden API exemption.");
        return;
    }

    jclass cls = env->FindClass("dalvik/system/VMRuntime");
    jmethodID getRuntime = env->GetStaticMethodID(cls, "getRuntime", "()Ldalvik/system/VMRuntime;");
    jobject runtime = env->CallStaticObjectMethod(cls, getRuntime);

    jclass arrayClass = env->FindClass("java/lang/String");
    jobjectArray exemptions = env->NewObjectArray(1, arrayClass, env->NewStringUTF("L"));

    typedef void (*ExemptFunc)(JNIEnv*, jclass, jobjectArray);
    ExemptFunc func = reinterpret_cast<ExemptFunc>(addr);
    func(env, cls, exemptions);

    LOGI("Hidden API disabled successfully.");
}
