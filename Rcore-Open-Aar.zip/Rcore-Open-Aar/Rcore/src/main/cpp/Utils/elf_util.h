#ifndef ELF_UTIL_H
#define ELF_UTIL_H

#include <cstdint>
#include <cstring>
#include <elf.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>

#define LOG_TAG "ElfUtil"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define PAGE_START(x) ((x) & ~(PAGE_SIZE - 1))

class ElfImg {
public:
    ElfImg(const char *elf_path) : base(nullptr), size(0), loaded(false) {
        int fd = open(elf_path, O_RDONLY);
        if (fd < 0) {
            LOGE("Failed to open ELF file: %s", elf_path);
            return;
        }

        off_t file_size = lseek(fd, 0, SEEK_END);
        if (file_size == -1) {
            LOGE("Failed to seek ELF file: %s", elf_path);
            close(fd);
            return;
        }
        lseek(fd, 0, SEEK_SET);

        base = mmap(nullptr, file_size, PROT_READ, MAP_PRIVATE, fd, 0);
        if (base == MAP_FAILED) {
            LOGE("Failed to mmap ELF file");
            base = nullptr;
            close(fd);
            return;
        }

        size = file_size;
        loaded = true;
        close(fd);
    }

    ~ElfImg() {
        if (loaded && base) {
            munmap(base, size);
        }
    }

    void *getSymbAddress(const char *symbolName) {
        if (!loaded) return nullptr;

        auto *ehdr = reinterpret_cast<Elf64_Ehdr *>(base);
        auto *shdr = reinterpret_cast<Elf64_Shdr *>((char *)base + ehdr->e_shoff);
        auto *shstr = (char *)base + shdr[ehdr->e_shstrndx].sh_offset;

        for (int i = 0; i < ehdr->e_shnum; ++i) {
            if (shdr[i].sh_type == SHT_DYNSYM) {
                Elf64_Shdr *strtab = &shdr[shdr[i].sh_link];
                const char *strings = (char *)base + strtab->sh_offset;
                Elf64_Sym *symtab = (Elf64_Sym *)((char *)base + shdr[i].sh_offset);
                int symbol_count = shdr[i].sh_size / sizeof(Elf64_Sym);

                for (int j = 0; j < symbol_count; ++j) {
                    const char *name = strings + symtab[j].st_name;
                    if (strcmp(name, symbolName) == 0) {
                        return (void *)(symtab[j].st_value);
                    }
                }
            }
        }
        return nullptr;
    }

private:
    void *base;
    size_t size;
    bool loaded;
};

#endif // ELF_UTIL_H
