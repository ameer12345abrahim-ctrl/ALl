#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <elf.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <android/log.h>

#define LOG_TAG "elf_util"
#define ALOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

template<typename T>
inline T* offsetOf(void* base, size_t offset) {
    return reinterpret_cast<T*>(reinterpret_cast<uintptr_t>(base) + offset);
}

bool findSymbolFromElf(const char* path, const char* symbol_name) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        ALOGD("Failed to open file: %s", path);
        return false;
    }

    off_t file_size = lseek(fd, 0, SEEK_END);
    void* mapped = mmap(nullptr, file_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);

    if (mapped == MAP_FAILED) {
        ALOGD("Failed to mmap file: %s", path);
        return false;
    }

    Elf64_Ehdr* header = (Elf64_Ehdr*)mapped;
    Elf64_Shdr* section_header = offsetOf<Elf64_Shdr>(header, header->e_shoff);
    char* section_str = offsetOf<char>(header, section_header[header->e_shstrndx].sh_offset);

    Elf64_Sym* dynsym_start = nullptr;
    Elf64_Sym* symtab_start = nullptr;
    const char* strtab_start = nullptr;
    const char* dynstr_start = nullptr;
    size_t dynsym_count = 0;
    size_t symtab_count = 0;

    for (int i = 0; i < header->e_shnum; ++i) {
        Elf64_Shdr* sh = &section_header[i];
        const char* section_name = section_str + sh->sh_name;

        if (strcmp(section_name, ".dynsym") == 0) {
            dynsym_start = offsetOf<Elf64_Sym>(header, sh->sh_offset);
            dynsym_count = sh->sh_size / sizeof(Elf64_Sym);
        } else if (strcmp(section_name, ".dynstr") == 0) {
            dynstr_start = offsetOf<const char>(header, sh->sh_offset);
        } else if (strcmp(section_name, ".symtab") == 0) {
            symtab_start = offsetOf<Elf64_Sym>(header, sh->sh_offset);
            symtab_count = sh->sh_size / sizeof(Elf64_Sym);
        } else if (strcmp(section_name, ".strtab") == 0) {
            strtab_start = offsetOf<const char>(header, sh->sh_offset);
        }
    }

    if (dynsym_start && dynstr_start) {
        for (size_t i = 0; i < dynsym_count; ++i) {
            const char* st_name = dynstr_start + dynsym_start[i].st_name;
            if (strcmp(st_name, symbol_name) == 0) {
                ALOGD("Symbol found in dynsym: %s", st_name);
                munmap(mapped, file_size);
                return true;
            }
        }
    }

    if (symtab_start && strtab_start) {
        for (size_t i = 0; i < symtab_count; ++i) {
            const char* st_name = strtab_start + symtab_start[i].st_name;
            if (strcmp(st_name, symbol_name) == 0) {
                ALOGD("Symbol found in symtab: %s", st_name);
                munmap(mapped, file_size);
                return true;
            }
        }
    }

    munmap(mapped, file_size);
    ALOGD("Symbol not found: %s", symbol_name);
    return false;
}
