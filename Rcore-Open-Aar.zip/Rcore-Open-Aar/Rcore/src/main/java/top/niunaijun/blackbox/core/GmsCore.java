package top.niunaijun.blackbox.core;

import android.content.pm.PackageManager;

import java.util.HashSet;
import java.util.Set;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

public class GmsCore {
    private static final String TAG = "GmsCore";

    private static final HashSet<String> GOOGLE_APP = new HashSet<>();
    private static final HashSet<String> GOOGLE_SERVICE = new HashSet<>();
    public static final String GMS_PKG = "com.google.android.gms";
    public static final String GSF_PKG = "com.google.android.gsf";
    public static final String VENDING_PKG = "com.android.vending";

    static {
        GOOGLE_APP.add(VENDING_PKG);
        GOOGLE_APP.add("com.google.android.play.games");
        GOOGLE_APP.add("com.google.android.wearable.app");
        GOOGLE_APP.add("com.google.android.wearable.app.cn");

        // GMS must install at first
        GOOGLE_SERVICE.add(GMS_PKG);
        GOOGLE_SERVICE.add(GSF_PKG);
        GOOGLE_SERVICE.add("com.google.android.gsf.login");
        GOOGLE_SERVICE.add("com.google.android.backuptransport");
        GOOGLE_SERVICE.add("com.google.android.backup");
        GOOGLE_SERVICE.add("com.google.android.configupdater");
        GOOGLE_SERVICE.add("com.google.android.syncadapters.contacts");
        GOOGLE_SERVICE.add("com.google.android.feedback");
        GOOGLE_SERVICE.add("com.google.android.onetimeinitializer");
        GOOGLE_SERVICE.add("com.google.android.partnersetup");
        GOOGLE_SERVICE.add("com.google.android.setupwizard");
        GOOGLE_SERVICE.add("com.google.android.syncadapters.calendar");
    }

    public static boolean isGoogleService(String packageName) {
        if (packageName == null) return false;
        return GOOGLE_SERVICE.contains(packageName);
    }

    public static boolean isGoogleAppOrService(String str) {
        if (str == null) return false;
        return GOOGLE_APP.contains(str) || GOOGLE_SERVICE.contains(str);
    }

    private static InstallResult installPackages(Set<String> list, int userId) {
        if (list == null) return new InstallResult();
        BlackBoxCore blackBoxCore = BlackBoxCore.get();
        if (blackBoxCore == null) return new InstallResult();

        for (String packageName : list) {
            if (packageName == null) continue;

            try {
                if (blackBoxCore.isInstalled(packageName, userId)) {
                    continue;
                }
            } catch (Throwable t) {
                t.printStackTrace();
                // If status check fails, skip this package gracefully
                continue;
            }

            try {
                if (BlackBoxCore.getContext() != null && BlackBoxCore.getContext().getPackageManager() != null) {
                    BlackBoxCore.getContext().getPackageManager().getApplicationInfo(packageName, 0);
                } else {
                    // Cannot verify availability; skip
                    continue;
                }
            } catch (PackageManager.NameNotFoundException e) {
                // Package not present; proceed to install
            } catch (Throwable t) {
                t.printStackTrace();
                continue;
            }

            InstallResult installResult = blackBoxCore.installPackageAsUser(packageName, userId);
            if (installResult == null || !installResult.success) {
                return installResult != null ? installResult : new InstallResult();
            }
        }
        return new InstallResult();
    }

    private static void uninstallPackages(Set<String> list, int userId) {
        if (list == null) return;
        BlackBoxCore blackBoxCore = BlackBoxCore.get();
        if (blackBoxCore == null) return;

        for (String packageName : list) {
            if (packageName == null) continue;
            try {
                blackBoxCore.uninstallPackageAsUser(packageName, userId);
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    public static InstallResult installGApps(int userId) {
        Set<String> googleApps = new HashSet<>();

        googleApps.addAll(GOOGLE_SERVICE);
        googleApps.addAll(GOOGLE_APP);

        InstallResult installResult = installPackages(googleApps, userId);
        if (installResult == null || !installResult.success) {
            uninstallGApps(userId);
            return installResult != null ? installResult : new InstallResult();
        }
        return installResult;
    }

    public static void uninstallGApps(int userId) {
        uninstallPackages(GOOGLE_SERVICE, userId);
        uninstallPackages(GOOGLE_APP, userId);
    }

    public static void remove(String packageName) {
        if (packageName == null) return;
        GOOGLE_SERVICE.remove(packageName);
        GOOGLE_APP.remove(packageName);
    }

    public static boolean isSupportGms() {
        try {
            BlackBoxCore.getPackageManager().getPackageInfo(GMS_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
        } catch (Throwable t) {
            // If something unexpected happens, be safe
            return false;
        }
        return false;
    }

    public static boolean isInstalledGoogleService(int userId) {
        try {
            return BlackBoxCore.get().isInstalled(GMS_PKG, userId);
        } catch (Throwable t) {
            return false;
        }
    }
}