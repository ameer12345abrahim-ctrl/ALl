package top.niunaijun.blackbox.fake.hook;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.delegate.AppInstrumentation;
import top.niunaijun.blackbox.fake.service.HCallbackProxy;
import top.niunaijun.blackbox.fake.service.IAccessibilityManagerProxy;
import top.niunaijun.blackbox.fake.service.IAccountManagerProxy;
import top.niunaijun.blackbox.fake.service.IActivityClientProxy;
import top.niunaijun.blackbox.fake.service.IActivityManagerProxy;
import top.niunaijun.blackbox.fake.service.IActivityTaskManagerProxy;
import top.niunaijun.blackbox.fake.service.IAlarmManagerProxy;
import top.niunaijun.blackbox.fake.service.IAppOpsManagerProxy;
import top.niunaijun.blackbox.fake.service.IAppWidgetManagerProxy;
import top.niunaijun.blackbox.fake.service.IAutofillManagerProxy;
import top.niunaijun.blackbox.fake.service.IConnectivityManagerProxy;
import top.niunaijun.blackbox.fake.service.IContextHubServiceProxy;
import top.niunaijun.blackbox.fake.service.IDeviceIdentifiersPolicyProxy;
import top.niunaijun.blackbox.fake.service.IDevicePolicyManagerProxy;
import top.niunaijun.blackbox.fake.service.IDisplayManagerProxy;
import top.niunaijun.blackbox.fake.service.IFingerprintManagerProxy;
import top.niunaijun.blackbox.fake.service.IGraphicsStatsProxy;
import top.niunaijun.blackbox.fake.service.IJobServiceProxy;
import top.niunaijun.blackbox.fake.service.ILauncherAppsProxy;
import top.niunaijun.blackbox.fake.service.ILocationManagerProxy;
import top.niunaijun.blackbox.fake.service.IMediaRouterServiceProxy;
import top.niunaijun.blackbox.fake.service.IMediaSessionManagerProxy;
import top.niunaijun.blackbox.fake.service.INetworkManagementServiceProxy;
import top.niunaijun.blackbox.fake.service.INotificationManagerProxy;
import top.niunaijun.blackbox.fake.service.IPackageManagerProxy;
import top.niunaijun.blackbox.fake.service.IPermissionManagerProxy;
import top.niunaijun.blackbox.fake.service.IPersistentDataBlockServiceProxy;
import top.niunaijun.blackbox.fake.service.IPhoneSubInfoProxy;
import top.niunaijun.blackbox.fake.service.IPowerManagerProxy;
import top.niunaijun.blackbox.fake.service.IShortcutManagerProxy;
import top.niunaijun.blackbox.fake.service.IStorageManagerProxy;
import top.niunaijun.blackbox.fake.service.IStorageStatsManagerProxy;
import top.niunaijun.blackbox.fake.service.ISystemUpdateProxy;
import top.niunaijun.blackbox.fake.service.ITelephonyManagerProxy;
import top.niunaijun.blackbox.fake.service.ITelephonyRegistryProxy;
import top.niunaijun.blackbox.fake.service.IUserManagerProxy;
import top.niunaijun.blackbox.fake.service.IVibratorServiceProxy;
import top.niunaijun.blackbox.fake.service.IVpnManagerProxy;
import top.niunaijun.blackbox.fake.service.IWifiManagerProxy;
import top.niunaijun.blackbox.fake.service.IWifiScannerProxy;
import top.niunaijun.blackbox.fake.service.IWindowManagerProxy;
import top.niunaijun.blackbox.fake.service.context.ContentServiceStub;
import top.niunaijun.blackbox.fake.service.context.RestrictionsManagerStub;
import top.niunaijun.blackbox.fake.service.libcore.OsStub;
import top.niunaijun.blackbox.utils.Slog;
import top.niunaijun.blackbox.utils.compat.BuildCompat;

/**
 * Created by Milk on 3/30/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class HookManager {
    public static final String TAG = "HookManager";

    private static final HookManager sHookManager = new HookManager();

    private final Map<Class<?>, IInjectHook> mInjectors = new HashMap<>();

    public static HookManager get() {
        return sHookManager;
    }

    public void init() {
        if (BlackBoxCore.get() != null && (BlackBoxCore.get().isBlackProcess() || BlackBoxCore.get().isServerProcess())) {
            addInjectorSafe(new IDisplayManagerProxy());
            addInjectorSafe(new OsStub());
            addInjectorSafe(new IActivityManagerProxy());
            addInjectorSafe(new IPackageManagerProxy());
            addInjectorSafe(new ITelephonyManagerProxy());
            addInjectorSafe(new HCallbackProxy());
            addInjectorSafe(new IAppOpsManagerProxy());
            addInjectorSafe(new INotificationManagerProxy());
            addInjectorSafe(new IAlarmManagerProxy());
            addInjectorSafe(new IAppWidgetManagerProxy());
            addInjectorSafe(new ContentServiceStub());
            addInjectorSafe(new IWindowManagerProxy());
            addInjectorSafe(new IUserManagerProxy());
            addInjectorSafe(new RestrictionsManagerStub());
            addInjectorSafe(new IMediaSessionManagerProxy());
            addInjectorSafe(new ILocationManagerProxy());
            addInjectorSafe(new IStorageManagerProxy());
            addInjectorSafe(new ILauncherAppsProxy());
            addInjectorSafe(new IJobServiceProxy());
            addInjectorSafe(new IAccessibilityManagerProxy());
            addInjectorSafe(new ITelephonyRegistryProxy());
            addInjectorSafe(new IDevicePolicyManagerProxy());
            addInjectorSafe(new IAccountManagerProxy());
            addInjectorSafe(new IConnectivityManagerProxy());
            addInjectorSafe(new IPhoneSubInfoProxy());
            addInjectorSafe(new IMediaRouterServiceProxy());
            addInjectorSafe(new IPowerManagerProxy());
            addInjectorSafe(new IContextHubServiceProxy());
            addInjectorSafe(new IVibratorServiceProxy());
            addInjectorSafe(new IPersistentDataBlockServiceProxy());
            addInjectorSafe(AppInstrumentation.get());
            /*
             * It takes time to test and enhance the compatibility of WifiManager
             * (only tested in Android 10).
             * commented by BlackBoxing at 2022/03/08
             * */
            addInjectorSafe(new IWifiManagerProxy());
            addInjectorSafe(new IWifiScannerProxy());
            // 12.0
            if (BuildCompat.isS()) {
                addInjectorSafe(new IActivityClientProxy(null));
                addInjectorSafe(new IVpnManagerProxy());
            }
            // 11.0
            if (BuildCompat.isR()) {
                addInjectorSafe(new IPermissionManagerProxy());
            }
            // 10.0
            if (BuildCompat.isQ()) {
                addInjectorSafe(new IActivityTaskManagerProxy());
            }
            // 9.0
            if (BuildCompat.isPie()) {
                addInjectorSafe(new ISystemUpdateProxy());
            }
            // 8.0
            if (BuildCompat.isOreo()) {
                addInjectorSafe(new IAutofillManagerProxy());
                addInjectorSafe(new IDeviceIdentifiersPolicyProxy());
                addInjectorSafe(new IStorageStatsManagerProxy());
            }
            // 7.1
            if (BuildCompat.isN_MR1()) {
                addInjectorSafe(new IShortcutManagerProxy());
            }
            // 7.0
            if (BuildCompat.isN()) {
                addInjectorSafe(new INetworkManagementServiceProxy());
            }
            // 6.0
            if (BuildCompat.isM()) {
                addInjectorSafe(new IFingerprintManagerProxy());
                addInjectorSafe(new IGraphicsStatsProxy());
            }
            // 5.0
            if (BuildCompat.isL()) {
                addInjectorSafe(new IJobServiceProxy());
            }
        }
        injectAll();
    }

    private void addInjectorSafe(IInjectHook injectHook) {
        if (injectHook != null && !mInjectors.containsKey(injectHook.getClass())) {
            try {
                addInjector(injectHook);
            } catch (Throwable t) {
                // Suppress to avoid detection/logging clear crash
                // Optionally add stealth logging here
            }
        }
    }

    public void checkEnv(Class<?> clazz) {
        if (clazz == null) return;
        IInjectHook iInjectHook = mInjectors.get(clazz);
        if (iInjectHook != null && iInjectHook.isBadEnv()) {
            Log.d(TAG, "checkEnv: " + clazz.getSimpleName() + " is bad env");
            try {
                iInjectHook.injectHook();
            } catch (Throwable ignored) {
            }
        }
    }

    public void checkAll() {
        if (mInjectors == null || mInjectors.isEmpty()) return;
        for (Class<?> aClass : mInjectors.keySet()) {
            if (aClass == null) continue;
            IInjectHook iInjectHook = mInjectors.get(aClass);
            if (iInjectHook != null && iInjectHook.isBadEnv()) {
                Log.d(TAG, "checkEnv: " + aClass.getSimpleName() + " is bad env");
                try {
                    iInjectHook.injectHook();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    void addInjector(IInjectHook injectHook) {
        if (injectHook == null) return;
        mInjectors.put(injectHook.getClass(), injectHook);
    }

    void injectAll() {
        if (mInjectors == null || mInjectors.isEmpty()) return;
        for (IInjectHook value : mInjectors.values()) {
            if (value == null) continue;
            try {
                Slog.d(TAG, "hook: " + value);
                value.injectHook();
            } catch (Throwable ignored) {
                // Suppress exceptions to avoid detection by logs/crashes
            }
        }
    }
}