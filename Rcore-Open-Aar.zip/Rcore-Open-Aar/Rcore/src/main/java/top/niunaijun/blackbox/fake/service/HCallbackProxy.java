package top.niunaijun.blackbox.fake.service;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ServiceInfo;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import java.lang.reflect.Proxy;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import black.android.app.ActivityThreadActivityClientRecordContext;
import black.android.app.BRActivityClient;
import black.android.app.BRActivityClientActivityClientControllerSingleton;
import black.android.app.BRActivityManagerNative;
import black.android.app.BRActivityThread;
import black.android.app.BRActivityThreadActivityClientRecord;
import black.android.app.BRActivityThreadCreateServiceData;
import black.android.app.BRActivityThreadH;
import black.android.os.BRHandler;
import black.android.app.servertransaction.BRClientTransaction;
import black.android.app.servertransaction.BRLaunchActivityItem;
import black.android.app.servertransaction.LaunchActivityItemContext;
import black.android.app.BRIActivityManager;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.fake.hook.IInjectHook;
import top.niunaijun.blackbox.proxy.ProxyManifest;
import top.niunaijun.blackbox.proxy.record.ProxyActivityRecord;
import top.niunaijun.blackbox.utils.Slog;
import top.niunaijun.blackbox.utils.compat.BuildCompat;

/**
 * Created by Milk on 3/31/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class HCallbackProxy implements IInjectHook, Handler.Callback {
    public static final String TAG = "HCallbackStub";
    private Handler.Callback mOtherCallback;
    private AtomicBoolean mBeing = new AtomicBoolean(false);

    private Handler.Callback getHCallback() {
        Handler h = getH();
        if (h == null) return null;
        try {
            return BRHandler.get(h).mCallback();
        } catch (Throwable t) {
            t.printStackTrace();
            return null;
        }
    }

    private Handler getH() {
        Object currentActivityThread = BlackBoxCore.mainThread();
        if (currentActivityThread == null) return null;
        try {
            return BRActivityThread.get(currentActivityThread).mH();
        } catch (Throwable t) {
            t.printStackTrace();
            return null;
        }
    }

    @Override
    public void injectHook() {
        mOtherCallback = getHCallback();
        if (mOtherCallback != null &&
                (mOtherCallback == this || mOtherCallback.getClass().getName().equals(this.getClass().getName()))) {
            mOtherCallback = null;
        }
        Handler h = getH();
        if (h != null) {
            try {
                BRHandler.get(h)._set_mCallback(this);
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    @Override
    public boolean isBadEnv() {
        Handler.Callback hCallback = getHCallback();
        return hCallback != null && hCallback != this;
    }

    @Override
    public boolean handleMessage(@NonNull Message msg) {
        if (!mBeing.getAndSet(true)) {
            try {
                if (BuildCompat.isPie()) {
                    if (msg.what == BRActivityThreadH.get().EXECUTE_TRANSACTION()) {
                        if (handleLaunchActivity(msg.obj)) {
                            Handler h = getH();
                            if (h != null) {
                                h.sendMessageAtFrontOfQueue(Message.obtain(msg));
                            }
                            return true;
                        }
                    }
                } else {
                    if (msg.what == BRActivityThreadH.get().LAUNCH_ACTIVITY()) {
                        if (handleLaunchActivity(msg.obj)) {
                            Handler h = getH();
                            if (h != null) {
                                h.sendMessageAtFrontOfQueue(Message.obtain(msg));
                            }
                            return true;
                        }
                    }
                }
                if (msg.what == BRActivityThreadH.get().CREATE_SERVICE()) {
                    return handleCreateService(msg.obj);
                }
                if (mOtherCallback != null) {
                    try {
                        return mOtherCallback.handleMessage(msg);
                    } catch (Throwable t) {
                        t.printStackTrace();
                        return false;
                    }
                }
                return false;
            } finally {
                mBeing.set(false);
            }
        }
        return false;
    }

    private Object getLaunchActivityItem(Object clientTransaction) {
        if (clientTransaction == null) return null;
        List<Object> mActivityCallbacks = null;
        try {
            mActivityCallbacks = BRClientTransaction.get(clientTransaction).mActivityCallbacks();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        if (mActivityCallbacks == null) return null;

        for (Object obj : mActivityCallbacks) {
            if (obj != null) {
                String className = null;
                try {
                    className = obj.getClass().getCanonicalName();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                if (BRLaunchActivityItem.getRealClass().getName().equals(className)) {
                    return obj;
                }
            }
        }
        return null;
    }

    private boolean handleLaunchActivity(Object client) {
        if (client == null) return false;

        Object r = null;
        try {
            if (BuildCompat.isPie()) {
                r = getLaunchActivityItem(client);
            } else {
                r = client;
            }
        } catch (Throwable e) {
            e.printStackTrace();
            return false;
        }
        if (r == null)
            return false;

        Intent intent = null;
        IBinder token = null;
        try {
            if (BuildCompat.isPie()) {
                try {
                    intent = BRLaunchActivityItem.get(r).mIntent();
                } catch (Throwable t) {
                    t.printStackTrace();
                    intent = null;
                }
                try {
                    token = BRClientTransaction.get(client).mActivityToken();
                } catch (Throwable t) {
                    t.printStackTrace();
                    token = null;
                }
            } else {
                ActivityThreadActivityClientRecordContext clientRecordContext = null;
                try {
                    clientRecordContext = BRActivityThreadActivityClientRecord.get(r);
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                if (clientRecordContext == null) return false;
                try {
                    intent = clientRecordContext.intent();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                try {
                    token = clientRecordContext.token();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            return false;
        }
        if (intent == null)
            return false;

        ProxyActivityRecord stubRecord = null;
        try {
            stubRecord = ProxyActivityRecord.create(intent);
        } catch (Throwable e) {
            e.printStackTrace();
            return false;
        }
        if (stubRecord == null) return false;

        ActivityInfo activityInfo = stubRecord.mActivityInfo;
        if (activityInfo != null) {
            try {
                // Ensure BActivityThread is non-null
                BActivityThread bActivityThread = null;
                try {
                    bActivityThread = BActivityThread.currentActivityThread();
                } catch (Throwable t) {
                    t.printStackTrace();
                }

                if (bActivityThread == null || BActivityThread.getAppConfig() == null) {
                    if (activityInfo.packageName != null && activityInfo.processName != null) {
                        try {
                            BlackBoxCore.getBActivityManager().restartProcess(activityInfo.packageName, activityInfo.processName, stubRecord.mUserId);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }

                    Intent launchIntentForPackage = null;
                    if (activityInfo.packageName != null) {
                        try {
                            launchIntentForPackage = BlackBoxCore.getBPackageManager().getLaunchIntentForPackage(activityInfo.packageName, stubRecord.mUserId);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                    if (launchIntentForPackage != null) {
                        try {
                            intent.setExtrasClassLoader(this.getClass().getClassLoader());
                            ProxyActivityRecord.saveStub(intent, launchIntentForPackage, stubRecord.mActivityInfo, stubRecord.mActivityRecord, stubRecord.mUserId);
                        } catch (Throwable e) {
                            e.printStackTrace();
                        }
                    }
                    if (BuildCompat.isPie()) {
                        LaunchActivityItemContext launchActivityItemContext = null;
                        try {
                            launchActivityItemContext = BRLaunchActivityItem.get(r);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                        if (launchActivityItemContext != null) {
                            try {
                                launchActivityItemContext._set_mIntent(intent);
                                launchActivityItemContext._set_mInfo(activityInfo);
                            } catch (Throwable t) {
                                t.printStackTrace();
                            }
                        }
                    } else {
                        ActivityThreadActivityClientRecordContext clientRecordContext = null;
                        try {
                            clientRecordContext = BRActivityThreadActivityClientRecord.get(r);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                        if (clientRecordContext != null) {
                            try {
                                clientRecordContext._set_intent(intent);
                                clientRecordContext._set_activityInfo(activityInfo);
                            } catch (Throwable t) {
                                t.printStackTrace();
                            }
                        }
                    }
                    // Critical guard: wait for Application initialization before returning success
                    if (bActivityThread == null || bActivityThread.getApplication() == null) {
                        return false;
                    }
                    return true;
                }
                // bind
                if (bActivityThread != null && !bActivityThread.isInit()) {
                    try {
                        bActivityThread.bindApplication(
                                activityInfo.packageName != null ? activityInfo.packageName : "",
                                activityInfo.processName != null ? activityInfo.processName : ""
                        );
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                    return true;
                }

                int taskId = 0;
                try {
                    if (token != null && BRActivityManagerNative.get() != null
                            && BRActivityManagerNative.get().getDefault() != null
                            && BRIActivityManager.get(BRActivityManagerNative.get().getDefault()) != null) {
                        taskId = BRIActivityManager.get(BRActivityManagerNative.get().getDefault()).getTaskForActivity(token, false);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    if (BlackBoxCore.getBActivityManager() != null && stubRecord.mActivityRecord != null) {
                        BlackBoxCore.getBActivityManager().onActivityCreated(taskId, token, stubRecord.mActivityRecord);
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }

                if (BuildCompat.isTiramisu()) {
                    LaunchActivityItemContext launchActivityItemContext = null;
                    try {
                        launchActivityItemContext = BRLaunchActivityItem.get(r);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                    if (launchActivityItemContext != null) {
                        try {
                            launchActivityItemContext._set_mIntent(stubRecord.mTarget);
                            launchActivityItemContext._set_mInfo(activityInfo);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                } else if (BuildCompat.isS()) {
                    Object record = null;
                    try {
                        if (BlackBoxCore.mainThread() != null &&
                                BRActivityThread.get(BlackBoxCore.mainThread()) != null &&
                                token != null) {
                            record = BRActivityThread.get(BlackBoxCore.mainThread()).getLaunchingActivity(token);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (record != null) {
                        ActivityThreadActivityClientRecordContext clientRecordContext = null;
                        try {
                            clientRecordContext = BRActivityThreadActivityClientRecord.get(record);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                        if (clientRecordContext != null) {
                            try {
                                clientRecordContext._set_intent(stubRecord.mTarget);
                                clientRecordContext._set_activityInfo(activityInfo);
                                if (bActivityThread != null) {
                                    clientRecordContext._set_packageInfo(bActivityThread.getPackageInfo());
                                }
                            } catch (Throwable t) {
                                t.printStackTrace();
                            }
                        }
                    }
                    checkActivityClient();
                } else if (BuildCompat.isPie()) {
                    LaunchActivityItemContext launchActivityItemContext = null;
                    try {
                        launchActivityItemContext = BRLaunchActivityItem.get(r);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                    if (launchActivityItemContext != null) {
                        try {
                            launchActivityItemContext._set_mIntent(stubRecord.mTarget);
                            launchActivityItemContext._set_mInfo(activityInfo);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                } else {
                    ActivityThreadActivityClientRecordContext clientRecordContext = null;
                    try {
                        clientRecordContext = BRActivityThreadActivityClientRecord.get(r);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                    if (clientRecordContext != null) {
                        try {
                            clientRecordContext._set_intent(stubRecord.mTarget);
                            clientRecordContext._set_activityInfo(activityInfo);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                }
            } catch (Throwable t) {
                t.printStackTrace();
                return false;
            }
        }
        return false;
    }

    private boolean handleCreateService(Object data) {
        if (BActivityThread.getAppConfig() != null) {
            String appPackageName = null;
            try {
                appPackageName = BActivityThread.getAppPackageName();
            } catch (Throwable t) {
                t.printStackTrace();
            }
            if (appPackageName == null) return false;

            ServiceInfo serviceInfo = null;
            try {
                serviceInfo = BRActivityThreadCreateServiceData.get(data).info();
            } catch (Throwable t) {
                t.printStackTrace();
            }
            if (serviceInfo == null) return false;

            if (!serviceInfo.name.equals(ProxyManifest.getProxyService(BActivityThread.getAppPid()))
                    && !serviceInfo.name.equals(ProxyManifest.getProxyJobService(BActivityThread.getAppPid()))) {
                Slog.d(TAG, "handleCreateService: " + data);
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(appPackageName, serviceInfo.name));
                try {
                    BlackBoxCore.getBActivityManager().startService(intent, null, false, BActivityThread.getUserId());
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                return true;
            }
        }
        return false;
    }

    private void checkActivityClient() {
        try {
            Object activityClientController = null;
            try {
                activityClientController = BRActivityClient.get().getActivityClientController();
            } catch (Throwable t) {
                t.printStackTrace();
            }
            if (activityClientController != null && !(activityClientController instanceof Proxy)) {
                IActivityClientProxy iActivityClientProxy = null;
                try {
                    iActivityClientProxy = new IActivityClientProxy(activityClientController);
                    iActivityClientProxy.onlyProxy(true);
                    iActivityClientProxy.injectHook();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                Object instance = null;
                try {
                    instance = BRActivityClient.get().getInstance();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
                if (instance != null) {
                    Object o = null;
                    try {
                        o = BRActivityClient.get(instance).INTERFACE_SINGLETON();
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                    if (o != null && iActivityClientProxy != null) {
                        try {
                            BRActivityClientActivityClientControllerSingleton.get(o)._set_mKnownInstance(iActivityClientProxy.getProxyInvocation());
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}